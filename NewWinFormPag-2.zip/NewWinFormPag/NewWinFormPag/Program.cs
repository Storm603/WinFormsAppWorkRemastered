using Microsoft.Data.Sqlite;
using NewWinFormPag;
using System;
using System.Drawing;
using System.Windows.Forms;

public class Form1 : System.Windows.Forms.Form
{   
    private Panel buttonPanel = new Panel();
    private DataGridView dataDataGridView = new DataGridView();
    private Button addNewRowButton = new Button();
    private Button deleteRowButton = new Button();
    private Button getNextPage = new Button();
    private Button getPreviousPage = new Button();
    private TextBox firstYear = new TextBox();
    private TextBox secondYear = new TextBox();
    private Button generateButton = new Button();
    private Label dashlabel = new Label();
    DBInstantiation connectionWithDB = new DBInstantiation();

    private int paginationIndex = 0;
    private long maxRecordCount = 0;

    public Form1()
    {
        this.Load += new EventHandler(Form1_Load);
       // this.dataDataGridView += new DataGridViewCellEventArgs(dataGridView1_CellClick);
    }

    private void Form1_Load(System.Object sender, System.EventArgs e)
    {
        SetupLayout();
        SetupDataGridView();
        PopulateDataGridView(ref paginationIndex);
    }

    //private void songsDataGridView_CellFormatting(object sender,
    //    System.Windows.Forms.DataGridViewCellFormattingEventArgs e)
    //{
    //    if (e != null)
    //    {
    //        if (this.dataDataGridView.Columns[e.ColumnIndex].Name == "Release Date")
    //        {
    //            if (e.Value != null)
    //            {
    //                try
    //                {
    //                    e.Value = DateTime.Parse(e.Value.ToString())
    //                        .ToLongDateString();
    //                    e.FormattingApplied = true;
    //                }
    //                catch (FormatException)
    //                {
    //                    Console.WriteLine("{0} is not a valid date.", e.Value.ToString());
    //                }
    //            }
    //        }
    //    }
    //}

    private void addNewRowButton_Click(object sender, EventArgs e)
    {
        this.dataDataGridView.Rows.Add();
    }

    private void deleteRowButton_Click(object sender, EventArgs e)
    {
        if (this.dataDataGridView.SelectedRows.Count > 0 &&
            this.dataDataGridView.SelectedRows[0].Index !=
            this.dataDataGridView.Rows.Count - 1)
        {
            this.dataDataGridView.Rows.RemoveAt(
                this.dataDataGridView.SelectedRows[0].Index);
        }
    }

    private void getPreviousPageButton_Click(object? sender, EventArgs e)
    {
        if (paginationIndex == 0)  return;

        dataDataGridView.Rows.Clear();

        paginationIndex -= 10;
        PopulateDataGridView(ref paginationIndex);
    }

    private void getNextPageButton_Click(object? sender, EventArgs e)
    {
        if (paginationIndex + 10 > maxRecordCount) return;
        dataDataGridView.Rows.Clear();

        paginationIndex += 10;
        PopulateDataGridView(ref paginationIndex);
    }

    private void GenerateRecordRange_Click(object sender, EventArgs e)
    {
        int first = 0;
        int second = 0;

        if (firstYear.Text == String.Empty && secondYear.Text == String.Empty)
        {
            MessageBox.Show("Please insert a year in the text boxes!", "No information!");
            return;
        }
            
        // SELECT * FROM [LineInformation] l JOIN [Data] d ON l.Id = d.LineId WHERE YEAR BETWEEN 2019 AND 2020 AND l.Id BETWEEN 565 AND 565 + 9
        // query for range selection

        try
        {
            first = int.Parse(firstYear.Text);
            second = int.Parse(secondYear.Text);
        }
        catch (Exception)
        {
            MessageBox.Show($"Write a year in the text boxes!", "Incorrect format input!");
            return;
        }

        if (first > second)
        {
            MessageBox.Show($"Write a year between 2019 and {DateTime.Now.Year}!", "Incorrect year input!");
            return;
        }

        SetupDataGridView();



        dataDataGridView.Columns[7].Visible = false;
        dataDataGridView.Columns[8].Visible = false;
        dataDataGridView.Columns[9].Visible = false;
        dataDataGridView.Columns[10].Visible = false;

        for (int i = first; i <= second; i++)
        {
            string yer = i.ToString;
            dataDataGridView.Columns[i.ToString].Visible = true;
        }
    }

    private void SetupLayout()
    {
        this.Size = new Size(1200, 500);

        addNewRowButton.Text = "Add Row";
        addNewRowButton.Location = new Point(10, 10);
        addNewRowButton.Click += new EventHandler(addNewRowButton_Click);

        deleteRowButton.Text = "Delete Row";
        deleteRowButton.Location = new Point(100, 10);
        deleteRowButton.Click += new EventHandler(deleteRowButton_Click);

        getNextPage.Text = ">";
        getNextPage.Location = new Point(310, 10);
        getNextPage.Click += new EventHandler(getNextPageButton_Click);
        //getNextPage.Size = new System.Drawing.Size(75, 35);

        getPreviousPage.Text = "<";
        getPreviousPage.Location = new Point(210, 10);
        getPreviousPage.Click += new EventHandler(getPreviousPageButton_Click);
        //getPreviousPage.Size = new System.Drawing.Size(75, 35);

        firstYear.Location = new Point(410, 10);
        dashlabel.Location = new Point(490, 10);
        dashlabel.Text = "-";
        secondYear.Location = new Point(570, 10);

        generateButton.Text = "Generate";
        generateButton.Location = new Point(700, 10);
        generateButton.Click += new EventHandler(GenerateRecordRange_Click);
        //getRightItems.Text = "Get next 10 items";
        //getRightItems.Size = new System.Drawing.Size(75, 35);
        //this.Controls.Add(getRightItems);
        //getRightItems.Click += getNextPageButton_Click;
        //        private TextBox firstYear = new TextBox();
        //private TextBox secondYear = new TextBox();


        buttonPanel.Controls.Add(addNewRowButton);
        buttonPanel.Controls.Add(deleteRowButton);
        buttonPanel.Controls.Add(getNextPage);
        buttonPanel.Controls.Add(getPreviousPage);
        buttonPanel.Controls.Add(firstYear);
        buttonPanel.Controls.Add(secondYear);
        buttonPanel.Controls.Add(generateButton);
        buttonPanel.Controls.Add(dashlabel);
        buttonPanel.Height = 50;
        buttonPanel.Dock = DockStyle.Bottom;

    //        private Button getRightItems = new Button();
    //private Button getNextPage = new Button();
    //private Button getPreviousPage = new Button();
    //private Button get10Items = new Button();
    //private Button get20Items = new Button();


        this.Controls.Add(this.buttonPanel);
    }



    private void SetupDataGridView()
    {
        dataDataGridView.AllowUserToAddRows = false;

        this.Controls.Add(dataDataGridView);

        dataDataGridView.ColumnCount = 12;

        dataDataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
        dataDataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        dataDataGridView.ColumnHeadersDefaultCellStyle.Font =
            new Font(dataDataGridView.Font, FontStyle.Bold);

        dataDataGridView.Name = "Line statistic in WAB";
        dataDataGridView.Location = new Point(8, 8);
        dataDataGridView.Size = new Size(500, 250);
        dataDataGridView.AutoSizeRowsMode =
            DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
        dataDataGridView.ColumnHeadersBorderStyle =
            DataGridViewHeaderBorderStyle.Single;
        dataDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
        dataDataGridView.GridColor = Color.Black;
        dataDataGridView.RowHeadersVisible = false;

        dataDataGridView.Columns[0].Name = "Id";
        dataDataGridView.Columns[1].Name = "PCT";
        dataDataGridView.Columns[2].Name = "Line";
        dataDataGridView.Columns[3].Name = "Zone";
        dataDataGridView.Columns[4].Name = "Workplace";
        dataDataGridView.Columns[5].Name = "Real Workplace";
        dataDataGridView.Columns[6].Name = "Area Before";
        dataDataGridView.Columns[7].Name = "2019";
        dataDataGridView.Columns[8].Name = "2020";
        dataDataGridView.Columns[9].Name = "2021";
        dataDataGridView.Columns[10].Name = "2022";
        dataDataGridView.Columns[11].Name = "Creation Date";


        //dataDataGridView.Columns[1].Visible = false;
        //dataDataGridView.Columns[10].DefaultCellStyle.Font =
        //new Font(dataDataGridView.DefaultCellStyle.Font, FontStyle.Italic);

        //DataGridViewRow row = (DataGridViewRow)dataDataGridView.CurrentCell.OwningRow;
        //int columnId = (int)row.Cells["Selector"].Value;

        //if (columnId == 0)
        //{
        dataDataGridView.SelectionMode =
                        DataGridViewSelectionMode.CellSelect;
            dataDataGridView.MultiSelect = false;
            dataDataGridView.Dock = DockStyle.Fill;
        //}
        //else
        //{
        //    dataDataGridView.SelectionMode =
        //                DataGridViewSelectionMode.CellSelect;
        //    dataDataGridView.MultiSelect = false;
        //    dataDataGridView.Dock = DockStyle.Fill;
        //}


        //dataDataGridView.CellFormatting += new
        // DataGridViewCellFormattingEventHandler(
        //songsDataGridView_CellFormatting);
    }

    private void PopulateDataGridView(ref int paginationIndex)
    {
        //dataDataGridView.Rows.Clear();
        //dataDataGridView.Refresh();
        

        List<string[]> listOfRecordsSplittedByArrayIndexes = connectionWithDB.RetrieveInformationFromDB(ref paginationIndex, ref maxRecordCount);

        for (int i = 0; i < listOfRecordsSplittedByArrayIndexes.Count; i++)
        {
            if (i == 0) continue;
            if (listOfRecordsSplittedByArrayIndexes[i] == null) break;
            dataDataGridView.Rows.Add(listOfRecordsSplittedByArrayIndexes[i]);
        }


        //foreach (var record in listOfRecordsSplittedByArrayIndexes)
        //{

        //}
        //string[] row0 = { "11/22/1968", "29", "Revolution 9",
        //    "Beatles", "The Beatles [White Album]" };
        //string[] row1 = { "1960", "6", "Fools Rush In",
        //    "Frank Sinatra", "Nice 'N' Easy" };
        //string[] row2 = { "11/11/1971", "1", "One of These Days",
        //    "Pink Floyd", "Meddle" };
        //string[] row3 = { "1988", "7", "Where Is My Mind?",
        //    "Pixies", "Surfer Rosa" };
        //string[] row4 = { "5/1981", "9", "Can't Find My Mind",
        //    "Cramps", "Psychedelic Jungle" };
        //string[] row5 = { "6/10/2003", "13",
        //    "Scatterbrain. (As Dead As Leaves.)",
        //    "Radiohead", "Hail to the Thief" };
        //string[] row6 = { "6/30/1992", "3", "Dress", "P J Harvey", "Dry" };

        //songsDataGridView.Rows.Add(row0);
        //songsDataGridView.Rows.Add(row1);
        //songsDataGridView.Rows.Add(row2);
        //songsDataGridView.Rows.Add(row3);
        //songsDataGridView.Rows.Add(row4);
        //songsDataGridView.Rows.Add(row5);
        //songsDataGridView.Rows.Add(row6);
        //songsDataGridView.Columns[0].DisplayIndex = 3;
        //songsDataGridView.Columns[1].DisplayIndex = 4;
        //songsDataGridView.Columns[2].DisplayIndex = 0;
        //songsDataGridView.Columns[3].DisplayIndex = 1;
        //songsDataGridView.Columns[4].DisplayIndex = 2;
    }


    [STAThreadAttribute()]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new Form1());
    }

    private void InitializeComponent()
    {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);

    }

    private void Form1_Load_1(object sender, EventArgs e)
    {

    }

    private void dataGridView1_CellClick(object sender,
    DataGridViewCellMouseEventArgs e)
    {
        if (dataDataGridView.CurrentCell.ColumnIndex.Equals(0) && e.RowIndex == 0)
        {
            //if (dataDataGridView.CurrentCell != null && dataDataGridView.CurrentCell.Value != null)
            //    MessageBox.Show(dataDataGridView.CurrentCell.Value.ToString());

            //if (columnId == 0)
            //{
            dataDataGridView.SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect;

        }
        else
        {
            dataDataGridView.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }
        //else
        //{
        //    dataDataGridView.SelectionMode =
        //                DataGridViewSelectionMode.CellSelect;
        //    dataDataGridView.MultiSelect = false;
        //    dataDataGridView.Dock = DockStyle.Fill;
        //}
    }
}