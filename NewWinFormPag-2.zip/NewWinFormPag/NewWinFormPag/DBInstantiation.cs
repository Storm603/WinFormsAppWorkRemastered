﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;



namespace NewWinFormPag
{
    public class DBInstantiation
    {
        private SqliteConnection conn;
        private string dbPath = "Data Source=DB.s3db";
        public DBInstantiation()
        {
            conn = new SqliteConnection(dbPath);
            dbPath = "";
            
        }

        public List<string[]> RetrieveInformationFromDB(ref int pagingForCycleIndex, ref long maxRecordCount) 
        {
            conn.Open();
            SqliteCommand cmd = new SqliteCommand(Queries.RETRIEVE_DB_RECORD_COUNT ,conn);
            object smth = cmd.ExecuteScalar();
            maxRecordCount = (long)smth;

            List<string[]> listOfRecordsInArrays = new List<string[]>();

            //string query = $@"SELECT *  FROM [LineInformation] l LEFT JOIN [Data] d ON l.Id = d.Id WHERE l.Id BETWEEN {pagingForCycleIndex} AND {pagingForCycleIndex + 9}";

            string query = $"SELECT * FROM LineInformation LIMIT 10 OFFSET {pagingForCycleIndex}; ";

            cmd = new SqliteCommand(query, conn);
            SqliteDataReader reader = cmd.ExecuteReader();

            int index = 0;

            //listOfRecordsInArrays.Add(new string[0]);

            while (reader.Read())
            {
                
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if (i == 0)
                    {
                        listOfRecordsInArrays.Add(new string[reader.FieldCount]);
                    }

                    if (Convert.IsDBNull(reader[i]))
                    {
                        listOfRecordsInArrays[index][i] = "N/A";
                        continue;
                    }

                    listOfRecordsInArrays[index][i] = reader.GetString(i);
                }

                index++;
            }

            listOfRecordsInArrays.Insert(0, new string[0]);
            conn.Close();
            return listOfRecordsInArrays;
        }
    }
}
