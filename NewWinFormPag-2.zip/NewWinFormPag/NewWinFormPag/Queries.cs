﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewWinFormPag
{
    public static class Queries
    {
        public const string RETRIEVE_DB_RECORD_COUNT = "SELECT COUNT(*) FROM LineInformation";
    }
}
